#pragma once

#include "App.xaml.g.h"

namespace winrt::CheckboxExampleWindows::implementation
{
    struct App : AppT<App>
    {
        App() noexcept;
    };
} // namespace winrt::CheckboxExampleWindows::implementation


